/**************************************************/
/*					  YOUR				          */
/*					  NEW						  */
/*                   FORTUNE					  */
/**************************************************/
/*                   ABOUT:                       */
/* This is a simple game coded predominantly in   */
/* the main c file that utilizes raylib, a header */
/* file for multiple platforms and multiple       */
/* languages that allows users to interface with  */
/* a GUI.                                         */
/**************************************************/
/*               INSTRUCTIONS:                    */
/* Download the raylib header file from the repos */
/* in the link below:                             */
/* https://www.raylib.com/                        */
/* After you have installed the header file, you  */
/* can unzip the file and start playing "Your New */
/* Fortune"!!                                     */
/**************************************************/